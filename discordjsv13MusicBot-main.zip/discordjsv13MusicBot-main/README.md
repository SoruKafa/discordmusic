# discordjsv13MusicBot
discord.js v13 Müzik Botu

## Adımlar
1) Botu sunucunuza alın.
2) Bota 'applitacion.commands' izni verin.
3) config.json doldurun.
4) Ve çalıştırın.

## Star atmayı unutmayın :)

## [Buraya tıklayarak kodlar paylaştığım sunucuya gidebilirsiniz.](https://discord.gg/Pur3RnGua2)
